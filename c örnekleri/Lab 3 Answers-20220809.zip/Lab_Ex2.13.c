#include<stdio.h>
#define INST_PRICE 7.5
int main()
{
	float length,width,price,total;
	printf("Enter the room length: ");
	scanf("%f",&length);
	printf("Enter the room width: ");
	scanf("%f",&width);
	printf("Enter the carpet price/square meter: ");
	scanf("%f",&price);
	total=(length*width)*(INST_PRICE+price);
	printf("Total cost is %.2f$.\n",total);
	return 0;
}
