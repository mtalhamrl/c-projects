#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Enter three integers: ");
	scanf("%d %d %d",&a,&b,&c);
	printf("Numbers in reverse order: %d %d %d\n",c,b,a);
	return 0;
}
