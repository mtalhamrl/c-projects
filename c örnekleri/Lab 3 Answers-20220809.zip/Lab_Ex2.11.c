#include<stdio.h>
int main()
{
	int h,m,s;
	printf("Enter hours: ");
	scanf("%d",&h);
	printf("Enter minutes: ");
	scanf("%d",&m);
	printf("Enter seconds: ");
	scanf("%d",&s);
	s=(h*3600)+(m*60)+s;
	printf("It is %d seconds.\n",s);
	return 0;
}
