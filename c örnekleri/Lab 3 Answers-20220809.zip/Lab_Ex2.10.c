#include<stdio.h>
int main()
{
	double F,C;
	
	printf("Enter temperature in Fahrenheit:");
	scanf("%lf",&F);
	
	C=(5.0/9.0)*(F-32);
	
	printf("%.2lf Fahrenheit equals to %.2lf Celcius.\n",F,C);
	return 0;
}
