#include<stdio.h>

int main()
{
	int n;
	
	printf("Enter an integer (0-15):");
	scanf("%d",&n);
	
	if(n>=0 && n<=9)
		printf("It is %d\n",n);
	else if(n==10)
		printf("It is A.\n");
	else if(n==11)
		printf("It is B.\n");
	else if(n==12)
		printf("It is C.\n");
	else if(n==13)
		printf("It is D.\n");
	else if(n==14)
		printf("It is E.\n");
	else if(n==15)
		printf("It is F.\n");
	else
		printf("It is out of range!!!\n");
		
	return 0;
}
