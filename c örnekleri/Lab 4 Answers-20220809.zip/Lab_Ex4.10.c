#include<stdio.h>

int main()
{
	char ch;
	int num1,num2;
	
	printf("Enter an operation symbol(+,-,*,/):");
	scanf("%c",&ch);
	
	printf("Enter two numbers:");
	scanf("%d %d", &num1, &num2);
	
	if(ch=='+')
	{
		printf("%d + %d is %d\n",num1,num2,num1+num2);
	}
	else if(ch=='-')
	{
		printf("%d - %d is %d\n",num1,num2,num1-num2);
	}
	else if(ch=='*')
	{
		printf("%d * %d is %d\n",num1,num2,num1*num2);
	}
	else if(ch=='/')
	{
		if(num2!=0)
		{
			printf("%d / %d is %d\n",num1,num2,num1/num2);
		}
		else
		{
			printf("Divisor cannot be zero!!!");
		}
	}
	else
	{
		printf("Error!!!");
	}
	
	return 0;
}
