#include<stdio.h>

int main()
{
	int side;
	char ch;
	
	printf("Enter the side of the square:");
	scanf("%d",&side);
	
	printf("Enter 'P' to print the perimeter\nEnter 'A' to print the area:");
	scanf(" %c",&ch);
	
	if(ch=='P')
	{
		printf("Perimeter of the square: %d\n",4*side);
	}
	else if(ch=='A')
	{
		printf("Area of the square: %d\n",side*side);
	}
	else
		printf("Error!!!");
		
	return 0;
}
