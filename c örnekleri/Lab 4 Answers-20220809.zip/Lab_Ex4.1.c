#include<stdio.h>

int main()
{
	int num1,num2,num3;
	
	printf("Enter 3 integer values:");
	scanf("%d %d %d",&num1,&num2,&num3);
	
	if(num1<0)
	{
		printf("%dx%dx%d = %d\n",num1,num2,num3,num1*num2*num3);
	}
	else
		printf("%d+%d+%d = %d\n",num1,num2,num3,num1+num2+num3);
		
	return 0;
}
